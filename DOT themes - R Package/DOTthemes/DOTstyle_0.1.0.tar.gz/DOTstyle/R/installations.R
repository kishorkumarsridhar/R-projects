# Installs the dependent packages

if (!require("ggplot2")) install.packages("ggplot2")
library(ggplot2)
if (!require("ggthemes")) install.packages("ggthemes")
library(ggthemes)
if (!require("extrafont")) install.packages("extrafont")
library(extrafont)
